/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thepizzashoppe;

import java.util.ArrayList;

/**
 *
 * @author acis15
 */


public class NewYorkPizza extends PizzaType {
    private ArrayList NYPizza = new ArrayList();
    PizzaType pizza;
    
	public NewYorkPizza() {
		description = "New York Pizza";
                 NYPizza.add(new PizzaDough(this));
                 pizza = (PizzaType)NYPizza.get(0);
                 System.out.println(pizza.getDescription());
	}
 
	public double cost() {
		return 13.21;
	}

 
}
