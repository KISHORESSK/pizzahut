/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thepizzashoppe;

/**
 *
 * @author acis15
 */
public class Sausage extends Toppings{
    	PizzaType pizzatype;

	public Sausage(PizzaType pizzatype) {
		this.pizzatype = pizzatype;
	}

	public String getDescription() {
		return pizzatype.getDescription() + ", Sausage";
	}

	public double cost() {
		return 2.50 + pizzatype.cost();
	}
}
