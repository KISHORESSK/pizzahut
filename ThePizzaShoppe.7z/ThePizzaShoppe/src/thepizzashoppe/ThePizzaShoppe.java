/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thepizzashoppe;

/**
 *
 * @author acis15
 */
public class ThePizzaShoppe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                PizzaType pizzatype = new NewYorkPizza();
		System.out.println(pizzatype.getDescription() 
				+ " $" + pizzatype.cost());
 
                
                
		//PizzaType pizzatype2 = new ChicagoPizza();
		//pizzatype2 = new Tomato(pizzatype2);
		//pizzatype2 = new SoyOil(pizzatype2);
		//pizzatype2 = new Chicken(pizzatype2);
		//System.out.println(pizzatype2.getDescription() 
				//+ " $" + pizzatype2.cost());
 /*
		Beverage beverage3 = new CaliforniaPizza();
		beverage3 = new Soy(beverage3);
		beverage3 = new Mocha(beverage3);
		beverage3 = new Whip(beverage3);
		System.out.println(beverage3.getDescription() 
				+ " $" + beverage3.cost());
                        */
    }
    
}
