/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thepizzashoppe;

/**
 *
 * @author acis15
 */
public class PizzaDough extends Dough{

 	PizzaType pizzatype;

	public PizzaDough(PizzaType pizzatype) {
		this.pizzatype = pizzatype;
	}

    PizzaDough() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

	public String getDescription() {
		return pizzatype.getDescription() + ", PizzaDough";
	}

	public double cost() {
		return .15 + pizzatype.cost();
	}
}
